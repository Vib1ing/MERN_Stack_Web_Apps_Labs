const requestLogger = (req, res, next) => {
    console.log(`Request Method: ${req.method}`);
    console.log(`Request URL: ${req.url}`);
    console.log("Request body:", req.body);
    console.log("------------");
    next();
};
  //middleware for error handling
  const errorHandler=(error, req, res, next)=>{
    console.log("Error Message", error.message);
    if(error.name==="CastError"){
      return res.status(400).json({error: "invalid id you silly willy"})
    }
  if(error.name==="ValidationError"){
      return res.status(400).json({error: "Not valid you silly goober"})
    }
    next(error)
  }
module.exports={requestLogger,errorHandler}